
import React, { useState, useCallback } from 'react';
import { UploadedFile } from './types';
import { fileToBase64 } from './utils/fileUtils';
import { generateFashionShoot } from './services/geminiService';
import { ImageUploader } from './components/ImageUploader';
import { ResultDisplay } from './components/ResultDisplay';
import { LoadingSpinner } from './components/LoadingSpinner';
import { CameraIcon, SparklesIcon } from './components/Icons';

const App: React.FC = () => {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFilesChange = (files: File[]) => {
    const processedFiles = files.map(file => ({
      file,
      preview: URL.createObjectURL(file),
    }));
    setUploadedFiles(processedFiles);
    setGeneratedImage(null);
    setError(null);
  };

  const handleGenerateClick = useCallback(async () => {
    if (uploadedFiles.length === 0) {
      setError("Lütfen en az bir kıyafet görseli yükleyin.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);

    try {
      const imageParts = await Promise.all(
        uploadedFiles.map(async (uploadedFile) => {
          const base64Data = await fileToBase64(uploadedFile.file);
          return {
            inlineData: {
              data: base64Data,
              mimeType: uploadedFile.file.type,
            },
          };
        })
      );
      
      const resultImage = await generateFashionShoot(imageParts);
      setGeneratedImage(`data:image/png;base64,${resultImage}`);
    } catch (err) {
      console.error(err);
      setError("Görsel oluşturulurken bir hata oluştu. Lütfen tekrar deneyin.");
    } finally {
      setIsLoading(false);
    }
  }, [uploadedFiles]);
  
  const handleReset = () => {
    setUploadedFiles([]);
    setGeneratedImage(null);
    setError(null);
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 flex flex-col items-center justify-center p-4 font-sans">
      <div className="w-full max-w-4xl mx-auto">
        <header className="text-center mb-8">
          <div className="flex justify-center items-center gap-4 mb-2">
            <CameraIcon className="w-12 h-12 text-pink-500" />
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 tracking-tight">
              AI Moda Çekimi
            </h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Kıyafetlerinizin görsellerini yükleyin, yapay zeka sizin için profesyonel stüdyo çekimleri oluştursun.
          </p>
        </header>

        <main className="bg-white rounded-2xl shadow-xl p-6 md:p-10 border border-gray-200">
          {!generatedImage && !isLoading && (
             <ImageUploader onFilesChange={handleFilesChange} uploadedFiles={uploadedFiles} />
          )}

          {isLoading && (
            <div className="flex flex-col items-center justify-center text-center h-64">
              <LoadingSpinner />
              <p className="text-lg font-semibold text-gray-700 mt-4">Moda çekiminiz hazırlanıyor...</p>
              <p className="text-gray-500">Bu işlem biraz zaman alabilir. Lütfen bekleyin.</p>
            </div>
          )}

          {error && (
            <div className="my-4 text-center p-4 bg-red-100 text-red-700 border border-red-200 rounded-lg">
              <p>{error}</p>
            </div>
          )}

          {generatedImage && !isLoading && (
            <ResultDisplay image={generatedImage} onReset={handleReset} />
          )}

          {!generatedImage && (
            <div className="mt-8 text-center">
              <button
                onClick={handleGenerateClick}
                disabled={isLoading || uploadedFiles.length === 0}
                className="inline-flex items-center justify-center px-8 py-4 bg-pink-600 text-white font-bold text-lg rounded-full shadow-lg hover:bg-pink-700 transition-all duration-300 transform hover:scale-105 disabled:bg-gray-400 disabled:cursor-not-allowed disabled:transform-none"
              >
                <SparklesIcon className="w-6 h-6 mr-3" />
                Çekimi Oluştur
              </button>
            </div>
          )}
        </main>
        
        <footer className="text-center mt-8">
            <p className="text-sm text-gray-500">Powered by Gemini AI</p>
        </footer>
      </div>
    </div>
  );
};

export default App;

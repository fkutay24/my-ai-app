
import React, { useCallback } from 'react';
import { UploadedFile } from '../types';
import { UploadIcon } from './Icons';

interface ImageUploaderProps {
  onFilesChange: (files: File[]) => void;
  uploadedFiles: UploadedFile[];
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onFilesChange, uploadedFiles }) => {
  
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      onFilesChange(Array.from(event.target.files));
    }
  };

  const handleDrop = useCallback((event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    event.stopPropagation();
    if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
      onFilesChange(Array.from(event.dataTransfer.files));
      event.dataTransfer.clearData();
    }
  }, [onFilesChange]);

  const handleDragOver = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    event.stopPropagation();
  };

  return (
    <div>
      <label
        htmlFor="file-upload"
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        className="relative block w-full rounded-lg border-2 border-dashed border-gray-300 p-12 text-center hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500 cursor-pointer transition-colors"
      >
        <UploadIcon className="mx-auto h-12 w-12 text-gray-400" />
        <span className="mt-2 block text-sm font-medium text-gray-900">
          Kıyafet görsellerini buraya sürükleyin
        </span>
        <span className="block text-xs text-gray-500">veya tıklayarak seçin</span>
      </label>
      <input
        id="file-upload"
        name="file-upload"
        type="file"
        multiple
        accept="image/*"
        className="sr-only"
        onChange={handleFileChange}
      />
      {uploadedFiles.length > 0 && (
        <div className="mt-6">
          <h3 className="text-lg font-medium text-gray-900">Yüklenen Kıyafetler:</h3>
          <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {uploadedFiles.map((uploadedFile, index) => (
              <div key={index} className="relative group aspect-w-1 aspect-h-1">
                <img
                  src={uploadedFile.preview}
                  alt={`Yüklenen önizleme ${index + 1}`}
                  className="object-cover w-full h-full rounded-md shadow-md border border-gray-200"
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

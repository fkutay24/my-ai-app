
import React from 'react';
import { DownloadIcon, RefreshIcon } from './Icons';

interface ResultDisplayProps {
  image: string;
  onReset: () => void;
}

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ image, onReset }) => {
  return (
    <div className="text-center">
      <h2 className="text-2xl font-bold text-gray-900 mb-4">İşte Moda Çekiminiz!</h2>
      <div className="relative group w-full max-w-2xl mx-auto rounded-lg shadow-2xl overflow-hidden border-4 border-white">
        <img src={image} alt="AI tarafından oluşturulan moda çekimi" className="w-full h-auto object-contain" />
      </div>
      <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
        <a
          href={image}
          download="ai-fashion-shoot.png"
          className="inline-flex items-center justify-center px-6 py-3 bg-green-600 text-white font-bold text-base rounded-full shadow-lg hover:bg-green-700 transition-all duration-300 transform hover:scale-105"
        >
          <DownloadIcon className="w-5 h-5 mr-2" />
          İndir
        </a>
        <button
          onClick={onReset}
          className="inline-flex items-center justify-center px-6 py-3 bg-gray-600 text-white font-bold text-base rounded-full shadow-lg hover:bg-gray-700 transition-all duration-300 transform hover:scale-105"
        >
          <RefreshIcon className="w-5 h-5 mr-2" />
          Yeniden Başla
        </button>
      </div>
    </div>
  );
};

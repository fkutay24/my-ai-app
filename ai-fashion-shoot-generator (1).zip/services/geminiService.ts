
import { GoogleGenAI, Modality, Part } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const FASHION_SHOOT_PROMPT = `Gönderilen kıyafetleri temel alarak, bu kıyafetlerin profesyonel bir moda çekiminde sergilendiği yüksek kaliteli bir görsel oluştur.

Özellikler:
- **Ortam:** Gerçekçi stüdyo ortamı.
- **Işıklandırma:** Profesyonel stüdyo ışıklandırması (softbox, üç nokta ışık sistemi gibi) kullanılarak aydınlık ve yumuşak gölgeli bir atmosfer yaratılmalı.
- **Arka Plan:** Temiz, dikkat dağıtmayan beyaz veya açık gri bir arka plan.
- **Tarz:** Yüksek çözünürlüklü, modern bir moda fotoğrafı.
- **Manken:** Kıyafetler profesyonel bir manken üzerinde kusursuz bir şekilde sergilenmeli. Manken, moda kataloğu veya lüks e-ticaret sitesi tarzında, doğal ve zarif bir poz vermeli. Duruşu kendinden emin olmalı.
- **ÖNEMLİ NOT:** Eğer yüklenen görsellerde bir insan yüzü veya figürü varsa, o kişiyi KESİNLİKLE KULLANMA. Bunun yerine, kıyafetleri sergilemek için tamamen yeni ve farklı, profesyonel bir stüdyo mankeni oluştur.
- **Kalite:** Kumaş dokusu, renk tonları ve dikiş gibi detaylar net, keskin ve fotoğrafik kalitede olmalı. Renkler gerçeğe uygun yansıtılmalı.
- **Genel Estetik:** Nihai görsel, Vogue, Zara veya Net-a-Porter gibi markaların kampanya çekimlerini andıran, sofistike ve ticari bir görünüme sahip olmalı.
`;

export const generateFashionShoot = async (imageParts: Part[]): Promise<string> => {
  const allParts: Part[] = [
    ...imageParts,
    { text: FASHION_SHOOT_PROMPT },
  ];

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: allParts,
    },
    config: {
      responseModalities: [Modality.IMAGE],
    },
  });

  if (response.candidates && response.candidates[0].content.parts[0].inlineData) {
    return response.candidates[0].content.parts[0].inlineData.data;
  }
  
  throw new Error("AI could not generate an image from the provided clothes.");
};


export interface UploadedFile {
  file: File;
  preview: string;
}
